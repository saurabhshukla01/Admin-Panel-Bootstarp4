## V 1.0.0
- Initial release

## V 2.0.0
- Material-components-web version updated to 3.2.0
- Modified folder structure
- Design improvements
- Bug fixes