# CHANGELOG

## V 3.0.0
- Better changes for file structure
- Design improvements
- Updated outdated plugins
- Bug fixes

## V 2.0.0
- Updated to bootstrap 4.1 version
- Improved design
- Migrated all plugins from bower component to npm component
- Removed deprecated plugins
- Better management of vendor files
- Other bug fixes

## V 1.0.0
- Initial release
